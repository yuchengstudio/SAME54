/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_init.h"
#include "utils.h"
#include "driver_examples.h"

static uint8_t src_data[512];
static uint8_t chk_data[512];
/**
 * Example of using FLASH_0 to read and write Flash main array.
 */
void FLASH_write(uint32_t dstaddr, uint8_t *buf, uint32_t length)
{
	/* Write data to flash */
	flash_write(&FLASH_0, dstaddr, buf, length);
}


static struct io_descriptor *io;

void EDBG_UART_enable(void)
{
	usart_sync_get_io_descriptor(&EDBG_UART, &io);
	usart_sync_enable(&EDBG_UART);
}


int32_t EDBG_UART_write(const uint8_t *const buf, const uint16_t len)
{
	return io_write(io, buf, len);	
}

int32_t EDBG_UART_read(uint8_t *const buf, const uint16_t len)
{
	return io_read(io, buf, len);
}
