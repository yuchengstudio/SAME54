#include <atmel_start.h>
#include "driver_examples.h"
#include "utils.h"

#define LED0 GPIO(GPIO_PORTC, 18)
#define BTN0 GPIO(GPIO_PORTB, 31)

#define NVM_PAGE_SIZE 128
uint8_t nvm_buf[NVM_PAGE_SIZE];

#define IFLASH_ADDR   0x00000000
#define APP_START_ADDRESS   (IFLASH_ADDR + 0x0008000)
#define APP_START_ADDRESS_RESET_ADDRESS   (APP_START_ADDRESS + 4)

#define DELAY_CNT_100MS 1

void init_app_envirnment(void)
{
      int i;
       __disable_irq();
	/* Disable SysTick */
	SysTick->CTRL = 0;
	/* Disable IRQs & clear pending IRQs */
	for (i = 0; i < 8; i++) {
		NVIC->ICER[i] = 0xFFFFFFFF;
		NVIC->ICPR[i] = 0xFFFFFFFF;
	}

	/* Modify vector table location */
	__DSB();
	__ISB();
	/* set the stack pointer also to the start of the firmware */
	__set_MSP(*(int *)(APP_START_ADDRESS));
	/* offset the start of the vector table (first 6 bits must be zero) */
	/* The register containing the offset, from 0x00000000, is at 0xE000ED08
	 **/
	SCB->VTOR = ((uint32_t)APP_START_ADDRESS_RESET_ADDRESS & SCB_VTOR_TBLOFF_Msk);
	__DSB();
	__ISB();
	__enable_irq();
	/* * (int *) 0xE000ED08 = FIRMWARE_START_ADDRESS; */
}
void boot_app(void){	
    /* jump to the start of the firmware, casting the address as function
	 * pointer to the start of the firmware. We want to jump to the address 
	 * of the reset */

	/* handler function, that is the value that is being pointed at position
	 * FIRMWARE_RESET_ADDRESS */
	void (*runFirmware)(void) = NULL;
	runFirmware = (void (*)(void))(*(uint32_t *)APP_START_ADDRESS_RESET_ADDRESS);
	runFirmware();
}

uint8_t check_app(void)
{
	uint32_t app_check_address;
	uint32_t *app_check_address_ptr;

	app_check_address = APP_START_ADDRESS;
	app_check_address_ptr = (uint32_t *) app_check_address;	
	
	if (*app_check_address_ptr == 0xFFFFFFFF) 
	{
		return 0; /* app is not ready */
	}
	
	return 1; /* start to download the app */
}

uint32_t len;
uint32_t recv_bytes = 0;

int main(void)
{
	uint8_t delay_cnt = DELAY_CNT_100MS;
	uint32_t offset;
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* initialize the LED pin */
	gpio_set_pin_direction(LED0, GPIO_DIRECTION_OUT);
	gpio_set_pin_level(LED0,true);
	gpio_set_pin_function(LED0, GPIO_PIN_FUNCTION_OFF);

	/* initialize the Button pin */
	gpio_set_pin_direction(BTN0, GPIO_DIRECTION_IN);
	gpio_set_pin_function(BTN0, GPIO_PIN_FUNCTION_OFF);

	/* waiting the SW0 button pressed */
	while (gpio_get_pin_level(BTN0) == true && --delay_cnt)
	{
		delay_ms(100);
		gpio_toggle_pin_level(LED0);;
	}

#if 0 /* no button pressed, boot to the application */	
	if (delay_cnt == 0 && check_app())
	{
		//jump to the application
		init_app_envirnment();
		boot_app();	
	}
#endif

	/* Replace with your application code */
	offset = 0;
	EDBG_UART_read(&len, 4);
	while (len != 0) {
		EDBG_UART_read(nvm_buf, min(NVM_PAGE_SIZE, len));

		//for debugging purpose
		recv_bytes += min(NVM_PAGE_SIZE, len);
		
		FLASH_write(APP_START_ADDRESS + NVM_PAGE_SIZE*offset++, nvm_buf, min(NVM_PAGE_SIZE, len));

		len -= min(NVM_PAGE_SIZE, len);
		EDBG_UART_write("s", 1);
	}

#if 1 /* for debugging */
	//jump to the application
	init_app_envirnment();
	boot_app();	
#endif 
}
