/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_examples.h"
#include "driver_init.h"
#include "utils.h"

/**
 * Example of using TARGET_IO to write "Hello World" using the IO abstraction.
 */
void TARGET_IO_example(void)
{
	struct io_descriptor *io;
	usart_sync_get_io_descriptor(&TARGET_IO, &io);
	usart_sync_enable(&TARGET_IO);

	io_write(io, (uint8_t *)"Hello World!", 12);
}

/**
 * Example of using Master_SPI to write "Hello World" using the IO abstraction.
 */
static uint8_t example_Master_SPI[12] = "Hello World!";

void Master_SPI_example(void)
{
	struct io_descriptor *io;
	spi_m_sync_get_io_descriptor(&Master_SPI, &io);

	spi_m_sync_enable(&Master_SPI);
	io_write(io, example_Master_SPI, 12);
}

/**
 * Example of using Slaver_SPI to write "Hello World" using the IO abstraction.
 *
 * Since the driver is asynchronous we need to use statically allocated memory for string
 * because driver initiates transfer and then returns before the transmission is completed.
 *
 * Once transfer has been completed the tx_cb function will be called.
 */

static uint8_t example_Slaver_SPI[12] = "Hello World!";

static void complete_cb_Slaver_SPI(const struct spi_s_async_descriptor *const desc)
{
	/* Transfer completed */
}

void Slaver_SPI_example(void)
{
	struct io_descriptor *io;
	spi_s_async_get_io_descriptor(&Slaver_SPI, &io);

	spi_s_async_register_callback(&Slaver_SPI, SPI_S_CB_TX, (FUNC_PTR)complete_cb_Slaver_SPI);
	spi_s_async_enable(&Slaver_SPI);
	io_write(io, example_Slaver_SPI, 12);
}
