/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_examples.h"
#include "driver_init.h"
#include "utils.h"

static void button_on_PB07_pressed(void)
{
}

/**
 * Example of using EXTERNAL_IRQ_0
 */
void EXTERNAL_IRQ_0_example(void)
{

	ext_irq_register(PIN_PB07, button_on_PB07_pressed);
}

/**
 * Example of using SPI_0 to write "Hello World" using the IO abstraction.
 *
 * Since the driver is asynchronous we need to use statically allocated memory for string
 * because driver initiates transfer and then returns before the transmission is completed.
 *
 * Once transfer has been completed the tx_cb function will be called.
 */

static uint8_t example_SPI_0[12] = "Hello World!";
volatile uint8_t TXComplete  = 0;

static void tx_complete_cb_SPI_0(struct _dma_resource *resource)
{
	/* Transfer completed */
	gpio_set_pin_level(SPI_M_CS, true);
	TXComplete = 1;
}

void SPI_0_example(void)
{
	struct io_descriptor *io;
	spi_m_dma_get_io_descriptor(&SPI_0, &io);

	spi_m_dma_register_callback(&SPI_0, SPI_M_DMA_CB_TX_DONE, tx_complete_cb_SPI_0);
	spi_m_dma_enable(&SPI_0);
	gpio_set_pin_level(SPI_M_CS, false);
	io_write(io, example_SPI_0, 12);
}

/**
 * Example of using SPI_1 to write "Hello World" using the IO abstraction.
 */

void SPI_1_example(void)
{
	spi_s_sync_enable(&SPI_1);
}
