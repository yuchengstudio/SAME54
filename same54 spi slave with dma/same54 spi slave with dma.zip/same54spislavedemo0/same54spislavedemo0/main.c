#include <atmel_start.h>

#include "hpl_dma.h"

#define SPI_TEST_SIZE 10

volatile uint32_t spi_tx_complete = 0;
volatile uint32_t spi_rx_complete = 0;

/**
 * Example of using Ethernet_SPI to write "Hello World" using the IO abstraction.
 */
static uint8_t example_SPI_MSTTX[SPI_TEST_SIZE] = {0,1,2,3,4,5,6,7,8,9};
static uint8_t example_SPI_MSTRX[SPI_TEST_SIZE] = {0};

static uint8_t example_SPI_SLVTX[SPI_TEST_SIZE] = {9,8,7,6,5,4,3,2,1,0};
static uint8_t example_SPI_SLVRX[SPI_TEST_SIZE] = {0};

/* SPI Slave Tx ����жϻص����� */
static void complete_cb_SPI_SLVTX(const struct spi_s_async_descriptor *const desc)
{
  /* Tx Transfer completed */
  spi_tx_complete = 1;
}

/* SPI Slave Tx ����жϻص����� */
static void complete_cb_SPI_SLVRX(const struct spi_s_async_descriptor *const desc)
{
  /* Rx Transfer completed */
  spi_rx_complete = 1;
}

void SPI_SLV_TX_RX_example(void)
{
  struct io_descriptor *io;
  spi_s_async_get_io_descriptor(&SPI_SLV, &io);

  spi_s_async_set_char_size(&SPI_SLV,SPI_CHAR_SIZE_8);

  /* ע��SPI Slave TX/RX���ʱ�Ļص����� - �����ָ���ֽ���SPI TX/RXʱ�����ע�����Ӧ�жϻص����� */
  spi_s_async_register_callback(&SPI_SLV, SPI_S_CB_TX, (FUNC_PTR)complete_cb_SPI_SLVTX);
  spi_s_async_register_callback(&SPI_SLV, SPI_S_CB_RX, (FUNC_PTR)complete_cb_SPI_SLVRX);
  spi_s_async_enable(&SPI_SLV);
}

static void spi_s_async_dma_enable(struct spi_s_async_descriptor *spi)
{
	ASSERT(spi);

	if (spi->enabled) {
		return;
	}

	if (_spi_sync_enable(spi->dev.prvt) != 0) {
		return;
	}
	spi->enabled = 1;
}

void spi_slave_dma_example(void)
{
	struct io_descriptor *io;
	spi_s_async_get_io_descriptor(&SPI_SLV, &io);

	spi_s_async_set_char_size(&SPI_SLV,SPI_CHAR_SIZE_8);

	spi_s_async_dma_enable(&SPI_SLV);
}

/************************************************************************/
/* SPI Slave Tx with DMA                                                */
/************************************************************************/

uint32_t spi_slv_tx_complete = 0;
uint32_t spi_slv_tx_error = 0;

#define CONFIG_SERCOM6_SPI_SLV_TXDMA_CHANNEL	0

static void spi_slv_dma_tx_enable(struct _spi_s_async_dev* dev)
{
	_spi_s_async_enable_tx(dev, true);
}

static void spi_slv_dma_tx_disable(struct _spi_s_async_dev* dev)
{
	_spi_s_async_enable_tx(dev, false);
}

/* callbacks */
static void spi_slv_dma_transfer_done_tx(struct _dma_resource *const resource)
{
	spi_slv_tx_complete = 1;
	_dma_enable_transaction(CONFIG_SERCOM6_SPI_SLV_TXDMA_CHANNEL, false);
}

static void spi_slv_dma_error_tx(struct _dma_resource *const resource)
{
	/* write error handling code here */
	spi_slv_tx_error = 1;
}

/* register callbacks */
void register_spi_slv_dma_tx_callback(void)
{
	struct _dma_resource *resource_tx;
	_dma_get_channel_resource(&resource_tx, CONFIG_SERCOM6_SPI_SLV_TXDMA_CHANNEL); 
	resource_tx->dma_cb.transfer_done = spi_slv_dma_transfer_done_tx;
	resource_tx->dma_cb.error         = spi_slv_dma_error_tx;
}

/* SERCOM RX channel configuration */
void configure_spi_slv_dma_tx(void)
{
	_dma_set_source_address(CONFIG_SERCOM6_SPI_SLV_TXDMA_CHANNEL, (uint32_t *)example_SPI_SLVTX);
	_dma_set_destination_address(CONFIG_SERCOM6_SPI_SLV_TXDMA_CHANNEL, (uint32_t* )&(((Sercom *)SERCOM6)->SPI.DATA.reg));
	_dma_set_data_amount(CONFIG_SERCOM6_SPI_SLV_TXDMA_CHANNEL, (uint32_t)SPI_TEST_SIZE);
	_dma_enable_transaction(CONFIG_SERCOM6_SPI_SLV_TXDMA_CHANNEL, false);

	/* callback */
	register_spi_slv_dma_tx_callback();

	/* Enable DMA transfer complete interrupt */
	_dma_set_irq_state(CONFIG_SERCOM6_SPI_SLV_TXDMA_CHANNEL, DMA_TRANSFER_COMPLETE_CB, true);
	spi_slv_dma_tx_enable(&SPI_SLV.dev);
}

/************************************************************************/
/* SPI Slave Rx with DMA                                                */
/************************************************************************/

uint32_t spi_slv_rx_complete = 0;
uint32_t spi_slv_rx_error = 0;

#define CONFIG_SERCOM6_SPI_SLV_RXDMA_CHANNEL	1

static void spi_slv_dma_rx_enable(struct _spi_s_async_dev* dev)
{
	_spi_s_async_enable_rx(dev, true);
	//_spi_s_async_enable_ss_detect(dev, true);
}

static void spi_slv_dma_rx_disable(struct _spi_s_async_dev* dev)
{
	_spi_s_async_enable_rx(dev, false);
}

/* callbacks */
static void spi_slv_dma_transfer_done_rx(struct _dma_resource *const resource)
{
	spi_slv_rx_complete = 1;
	_dma_enable_transaction(CONFIG_SERCOM6_SPI_SLV_RXDMA_CHANNEL, false);
}

static void spi_slv_dma_error_rx(struct _dma_resource *const resource)
{
	/* write error handling code here */
	spi_slv_rx_error = 1;
}

/* register callbacks */
static void register_spi_slv_dma_rx_callback(void)
{
	struct _dma_resource *resource_rx;
	_dma_get_channel_resource(&resource_rx, CONFIG_SERCOM6_SPI_SLV_RXDMA_CHANNEL);
	resource_rx->dma_cb.transfer_done = spi_slv_dma_transfer_done_rx;
	resource_rx->dma_cb.error         = spi_slv_dma_error_rx;
}

/* SERCOM RX channel configuration */
void configure_spi_slv_dma_rx(void)
{
	_dma_set_source_address(CONFIG_SERCOM6_SPI_SLV_RXDMA_CHANNEL, (uint32_t* )&(((Sercom *)SERCOM6)->SPI.DATA.reg));
	_dma_set_destination_address(CONFIG_SERCOM6_SPI_SLV_RXDMA_CHANNEL, (uint32_t *)example_SPI_SLVRX);
	_dma_set_data_amount(CONFIG_SERCOM6_SPI_SLV_RXDMA_CHANNEL, (uint32_t)SPI_TEST_SIZE);
	_dma_enable_transaction(CONFIG_SERCOM6_SPI_SLV_RXDMA_CHANNEL, false);

	/* callback */
	register_spi_slv_dma_rx_callback();

	/* Enable DMA transfer complete interrupt */
	_dma_set_irq_state(CONFIG_SERCOM6_SPI_SLV_RXDMA_CHANNEL, DMA_TRANSFER_COMPLETE_CB, true);
	spi_slv_dma_rx_enable(&SPI_SLV.dev);
}

void SPI_MST_TX_RX_example(void)
{
	struct io_descriptor *io;
	spi_m_sync_get_io_descriptor(&Ethernet_SPI, &io);

	spi_m_sync_enable(&Ethernet_SPI);
}

int main(void)
{
	uint32_t i = 0;
	struct spi_xfer xfer;
	struct io_descriptor *slv_spi_io;
  
	xfer.rxbuf = example_SPI_MSTRX;
	xfer.txbuf = example_SPI_MSTTX; 
	xfer.size  = SPI_TEST_SIZE; 
  
	spi_s_async_get_io_descriptor(&SPI_SLV, &slv_spi_io);
  
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Enabled Cache controller and Enable ICache/Disable DCache */
	hri_cmcc_write_CTRL_reg(CMCC,CMCC_CTRL_CEN);
	hri_cmcc_write_CFG_reg(CMCC, CMCC_CFG_DCDIS | CMCC_CFG_CSIZESW_CONF_CSIZE_4KB);
  
	SPI_MST_TX_RX_example();
	SPI_SLV_TX_RX_example();
	configure_spi_slv_dma_rx();
	configure_spi_slv_dma_tx();	
  
	/* Replace with your application code */
	while (1) {
    printf("spi slave sending:\r\n");
    for (i = 0; i < SPI_TEST_SIZE; i++) {
      printf("0x%02X ",example_SPI_SLVTX[i]);
    }
    printf("\r\n");
    //io_write(slv_spi_io, example_SPI_SLVTX, SPI_TEST_SIZE);  /* ���嵥��SPI Slave TX�ֽ����� */
    
    gpio_set_pin_level(SPI_KSZ8851SNL_CS, false);
	spi_slv_dma_rx_enable(&SPI_SLV.dev);
	spi_slv_dma_tx_enable(&SPI_SLV.dev);	
    spi_m_sync_transfer(&Ethernet_SPI, &xfer);
    gpio_set_pin_level(SPI_KSZ8851SNL_CS, true);
    
    printf("spi master sending:\r\n");
    for (i = 0; i < SPI_TEST_SIZE; i++) {
      printf("0x%02X ",example_SPI_MSTTX[i]);
    }
    printf("\r\n");    
    
	delay_ms(2000);
	
	spi_slv_tx_complete = 0;
	spi_slv_rx_complete = 0;
    
    printf("spi slave receiving:\r\n");
    for (i = 0; i < SPI_TEST_SIZE; i++) {
      printf("0x%02X ",example_SPI_SLVRX[i]);
    }
    printf("\r\n");    
    
    printf("spi master receiving:\r\n");
    for (i = 0; i < SPI_TEST_SIZE; i++) {
      printf("0x%02X ",example_SPI_MSTRX[i]);
    }
    printf("\r\n");    
    
    memset(example_SPI_MSTRX,0,SPI_TEST_SIZE);
    memset(example_SPI_SLVRX,0,SPI_TEST_SIZE);
    
	}
}
