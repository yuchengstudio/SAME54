/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_init.h"
#include <peripheral_clk_config.h>
#include <utils.h>
#include <hal_init.h>
#include <hpl_adc_base.h>

struct spi_m_sync_descriptor Ethernet_SPI;
struct timer_descriptor      ETHERNET_TICK;

struct adc_sync_descriptor ADC_0;

struct usart_sync_descriptor TARGET_IO;

struct spi_s_async_descriptor SPI_SLV;
static uint16_t               SPI_SLV_buf[32];

void ADC_0_PORT_init(void)
{

	// Disable digital pin circuitry
	gpio_set_pin_direction(PC02, GPIO_DIRECTION_OFF);

	gpio_set_pin_function(PC02, PINMUX_PC02B_ADC1_AIN4);
}

void ADC_0_CLOCK_init(void)
{
	hri_mclk_set_APBDMASK_ADC1_bit(MCLK);
	hri_gclk_write_PCHCTRL_reg(GCLK, ADC1_GCLK_ID, CONF_GCLK_ADC1_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
}

void ADC_0_init(void)
{
	ADC_0_CLOCK_init();
	ADC_0_PORT_init();
	adc_sync_init(&ADC_0, ADC1, (void *)NULL);
}

void ETHERNET_IRQ_0_init(void)
{
	hri_gclk_write_PCHCTRL_reg(GCLK, EIC_GCLK_ID, CONF_GCLK_EIC_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_mclk_set_APBAMASK_EIC_bit(MCLK);

	ext_irq_init();

	// Set pin direction to input
	gpio_set_pin_direction(PB07, GPIO_DIRECTION_IN);

	gpio_set_pin_pull_mode(PB07,
	                       // <y> Pull configuration
	                       // <id> pad_pull_config
	                       // <GPIO_PULL_OFF"> Off
	                       // <GPIO_PULL_UP"> Pull-up
	                       // <GPIO_PULL_DOWN"> Pull-down
	                       GPIO_PULL_OFF);

	gpio_set_pin_function(PB07, PINMUX_PB07A_EIC_EXTINT7);
}

void TARGET_IO_PORT_init(void)
{

	gpio_set_pin_function(PB25, PINMUX_PB25D_SERCOM2_PAD0);

	gpio_set_pin_function(PB24, PINMUX_PB24D_SERCOM2_PAD1);
}

void TARGET_IO_CLOCK_init(void)
{
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM2_GCLK_ID_CORE, CONF_GCLK_SERCOM2_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM2_GCLK_ID_SLOW, CONF_GCLK_SERCOM2_SLOW_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));

	hri_mclk_set_APBBMASK_SERCOM2_bit(MCLK);
}

void TARGET_IO_init(void)
{
	TARGET_IO_CLOCK_init();
	usart_sync_init(&TARGET_IO, SERCOM2, (void *)NULL);
	TARGET_IO_PORT_init();
}

void Ethernet_SPI_PORT_init(void)
{

	// Set pin direction to output - MOSI
	gpio_set_pin_direction(PB27, GPIO_DIRECTION_OUT);

	gpio_set_pin_level(PB27,
	                   // <y> Initial level
	                   // <id> pad_initial_level
	                   // <false"> Low
	                   // <true"> High
	                   false);

	gpio_set_pin_function(PB27, PINMUX_PB27D_SERCOM4_PAD0);

	// Set pin direction to output - SCK
	gpio_set_pin_direction(PB26, GPIO_DIRECTION_OUT);

	gpio_set_pin_level(PB26,
	                   // <y> Initial level
	                   // <id> pad_initial_level
	                   // <false"> Low
	                   // <true"> High
	                   false);

	gpio_set_pin_function(PB26, PINMUX_PB26D_SERCOM4_PAD1);

	// Set pin direction to input - MISO
	gpio_set_pin_direction(PB29, GPIO_DIRECTION_IN);

	gpio_set_pin_pull_mode(PB29,
	                       // <y> Pull configuration
	                       // <id> pad_pull_config
	                       // <GPIO_PULL_OFF"> Off
	                       // <GPIO_PULL_UP"> Pull-up
	                       // <GPIO_PULL_DOWN"> Pull-down
	                       GPIO_PULL_OFF);

	gpio_set_pin_function(PB29, PINMUX_PB29D_SERCOM4_PAD3);
}

void Ethernet_SPI_CLOCK_init(void)
{
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM4_GCLK_ID_CORE, CONF_GCLK_SERCOM4_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM4_GCLK_ID_SLOW, CONF_GCLK_SERCOM4_SLOW_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));

	hri_mclk_set_APBDMASK_SERCOM4_bit(MCLK);
}

void Ethernet_SPI_init(void)
{
	Ethernet_SPI_CLOCK_init();
	spi_m_sync_init(&Ethernet_SPI, SERCOM4);
	Ethernet_SPI_PORT_init();
}

void SPI_SLV_PORT_init(void)
{

	// Set pin direction to output - MISO
	gpio_set_pin_direction(PC04, GPIO_DIRECTION_OUT);

	gpio_set_pin_level(PC04,
	                   // <y> Initial level
	                   // <id> pad_initial_level
	                   // <false"> Low
	                   // <true"> High
	                   false);

	gpio_set_pin_function(PC04, PINMUX_PC04C_SERCOM6_PAD0);

	// Set pin direction to output - SCK
	gpio_set_pin_direction(PC05, GPIO_DIRECTION_OUT);

	gpio_set_pin_level(PC05,
	                   // <y> Initial level
	                   // <id> pad_initial_level
	                   // <false"> Low
	                   // <true"> High
	                   false);

	gpio_set_pin_function(PC05, PINMUX_PC05C_SERCOM6_PAD1);

	// Set pin direction to input - CS
	gpio_set_pin_direction(PC06, GPIO_DIRECTION_IN);

	gpio_set_pin_pull_mode(PC06,
	                       // <y> Pull configuration
	                       // <id> pad_pull_config
	                       // <GPIO_PULL_OFF"> Off
	                       // <GPIO_PULL_UP"> Pull-up
	                       // <GPIO_PULL_DOWN"> Pull-down
	                       GPIO_PULL_OFF);

	gpio_set_pin_function(PC06, PINMUX_PC06C_SERCOM6_PAD2);

	// Set pin direction to input - MOSI
	gpio_set_pin_direction(PC07, GPIO_DIRECTION_IN);

	gpio_set_pin_pull_mode(PC07,
	                       // <y> Pull configuration
	                       // <id> pad_pull_config
	                       // <GPIO_PULL_OFF"> Off
	                       // <GPIO_PULL_UP"> Pull-up
	                       // <GPIO_PULL_DOWN"> Pull-down
	                       GPIO_PULL_OFF);

	gpio_set_pin_function(PC07, PINMUX_PC07C_SERCOM6_PAD3);
}

void SPI_SLV_CLOCK_init(void)
{
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM6_GCLK_ID_CORE, CONF_GCLK_SERCOM6_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM6_GCLK_ID_SLOW, CONF_GCLK_SERCOM6_SLOW_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));

	hri_mclk_set_APBDMASK_SERCOM6_bit(MCLK);
}

void SPI_SLV_init(void)
{
	SPI_SLV_CLOCK_init();
	spi_s_async_init(&SPI_SLV, SERCOM6, (uint8_t *)SPI_SLV_buf, 64);
	SPI_SLV_PORT_init();
}

void delay_driver_init(void)
{
	delay_init(SysTick);
}

/**
 * \brief Timer initialization function
 *
 * Enables Timer peripheral, clocks and initializes Timer driver
 */
static void ETHERNET_TICK_init(void)
{
	hri_mclk_set_APBAMASK_TC0_bit(MCLK);
	hri_gclk_write_PCHCTRL_reg(GCLK, TC0_GCLK_ID, CONF_GCLK_TC0_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));

	timer_init(&ETHERNET_TICK, TC0, _tc_get_timer());
}

void system_init(void)
{
	init_mcu();

	// GPIO on PA06

	// Set pin direction to input
	gpio_set_pin_direction(KSZ8851SNL_PME, GPIO_DIRECTION_IN);

	gpio_set_pin_pull_mode(KSZ8851SNL_PME,
	                       // <y> Pull configuration
	                       // <id> pad_pull_config
	                       // <GPIO_PULL_OFF"> Off
	                       // <GPIO_PULL_UP"> Pull-up
	                       // <GPIO_PULL_DOWN"> Pull-down
	                       GPIO_PULL_OFF);

	gpio_set_pin_function(KSZ8851SNL_PME, GPIO_PIN_FUNCTION_OFF);

	// GPIO on PA07

	// Set pin direction to output
	gpio_set_pin_direction(KSZ8851SNL_nRST, GPIO_DIRECTION_OUT);

	gpio_set_pin_level(KSZ8851SNL_nRST,
	                   // <y> Initial level
	                   // <id> pad_initial_level
	                   // <false"> Low
	                   // <true"> High
	                   true);

	gpio_set_pin_function(KSZ8851SNL_nRST, GPIO_PIN_FUNCTION_OFF);

	// GPIO on PB28

	// Set pin direction to output
	gpio_set_pin_direction(SPI_KSZ8851SNL_CS, GPIO_DIRECTION_OUT);

	gpio_set_pin_level(SPI_KSZ8851SNL_CS,
	                   // <y> Initial level
	                   // <id> pad_initial_level
	                   // <false"> Low
	                   // <true"> High
	                   true);

	gpio_set_pin_function(SPI_KSZ8851SNL_CS, GPIO_PIN_FUNCTION_OFF);

	// GPIO on PC18

	// Set pin direction to output
	gpio_set_pin_direction(USER_LED0, GPIO_DIRECTION_OUT);

	gpio_set_pin_level(USER_LED0,
	                   // <y> Initial level
	                   // <id> pad_initial_level
	                   // <false"> Low
	                   // <true"> High
	                   true);

	gpio_set_pin_function(USER_LED0, GPIO_PIN_FUNCTION_OFF);

	ADC_0_init();

	ETHERNET_IRQ_0_init();

	TARGET_IO_init();

	Ethernet_SPI_init();

	SPI_SLV_init();

	delay_driver_init();

	ETHERNET_TICK_init();
}
