#include <atmel_start.h>
uint8_t adc_result;
static void convert_cb_ADC_cb(const struct adc_async_descriptor *const descr, const uint8_t channel)
{
	
	if(ADC0->INPUTCTRL.reg == 0x180c) //Check if channel 12 is converted (PB00 <--> AN12)
	{
	adc_result = hri_adc_read_RESULT_reg(ADC_0.device.hw);	
	
	hri_adc_write_INPUTCTRL_reg(ADC_0.device.hw,0x1806); //switch to ADC_0 channel 6
	adc_async_enable_channel(&ADC_0, 0);
	adc_async_start_conversion(&ADC_0);	
	}
	
	
	if(ADC0->INPUTCTRL.reg == 0x1806) //Check if channel 6 is converted (PB04 <--> AN06)
	{
	adc_result = hri_adc_read_RESULT_reg(ADC_0.device.hw);
	asm("nop");
	}
}

void ADC_0_function(void)
{
	//set the ADC connect to channel 12
	hri_adc_write_INPUTCTRL_reg(ADC_0.device.hw, 0x1806);	
	adc_async_enable_channel(&ADC_0, 0);
	adc_async_register_callback(&ADC_0, 0, ADC_ASYNC_CONVERT_CB, convert_cb_ADC_cb);
	adc_async_start_conversion(&ADC_0);
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	/* Replace with your application code */
	while (1) {
		
		ADC_0_function();
		
	}
}
