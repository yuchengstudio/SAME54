/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_examples.h"
#include "driver_init.h"
#include "utils.h"

uint8_t orgin_array[100] ={"and, you can find a new world\n\r"};
uint8_t object_array[100] ={"try to change your mind\n"};
/**
 * Example of using TARGET_IO to write "Hello World" using the IO abstraction.
 */
void TARGET_IO_example(void)
{
	struct io_descriptor *io;
	usart_sync_get_io_descriptor(&TARGET_IO, &io);
	usart_sync_enable(&TARGET_IO);

	io_write(io, (uint8_t *)"Hello World!\n\r", 14);
	uint8_t object_array[100] ={"try to change your mind\n\r"};
	io_write(io, object_array, sizeof(object_array));
	
	//copy, and print it via uart
	memcpy(&object_array[0], &orgin_array[0],sizeof(orgin_array));
	io_write(io, object_array, sizeof(object_array));
	io_write(io, (uint8_t *)"=========================================\n\r", 45);
	
	
}
