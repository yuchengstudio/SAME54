#include <atmel_start.h>
#include "arm_math_tcm.h"
//#include "arm_math.h"
#include "math_helper.h"

/* ----------------------------------------------------------------------
** Macro Defines
** ------------------------------------------------------------------- */

#define TEST_LENGTH_SAMPLES  320
#define SNR_THRESHOLD_F32    140.0f
#define BLOCK_SIZE            32
#define NUM_TAPS              29

/* -------------------------------------------------------------------
 * The input signal and reference output (computed with MATLAB)
 * are defined externally in arm_fir_lpf_data.c.
 * ------------------------------------------------------------------- */

extern float32_t testInput_f32_1kHz_15kHz[TEST_LENGTH_SAMPLES];
extern float32_t refOutput[TEST_LENGTH_SAMPLES];

/* -------------------------------------------------------------------
 * Declare Test output buffer
 * ------------------------------------------------------------------- */

static float32_t testOutput[TEST_LENGTH_SAMPLES];

/* -------------------------------------------------------------------
 * Declare State buffer of size (numTaps + blockSize - 1)
 * ------------------------------------------------------------------- */

static float32_t firStateF32[BLOCK_SIZE + NUM_TAPS - 1];

/* ----------------------------------------------------------------------
** FIR Coefficients buffer generated using fir1() MATLAB function.
** fir1(28, 6/24)
** ------------------------------------------------------------------- */

float32_t firCoeffs32[NUM_TAPS] = {
  -0.0018225230f, -0.0015879294f, +0.0000000000f, +0.0036977508f, +0.0080754303f, +0.0085302217f, -0.0000000000f, -0.0173976984f,
  -0.0341458607f, -0.0333591565f, +0.0000000000f, +0.0676308395f, +0.1522061835f, +0.2229246956f, +0.2504960933f, +0.2229246956f,
  +0.1522061835f, +0.0676308395f, +0.0000000000f, -0.0333591565f, -0.0341458607f, -0.0173976984f, -0.0000000000f, +0.0085302217f,
  +0.0080754303f, +0.0036977508f, +0.0000000000f, -0.0015879294f, -0.0018225230f
};

/* ------------------------------------------------------------------
 * Global variables for FIR LPF Example
 * ------------------------------------------------------------------- */

uint32_t blockSize = BLOCK_SIZE;
uint32_t numBlocks = TEST_LENGTH_SAMPLES/BLOCK_SIZE;
volatile uint32_t systick_count_a = 0;
volatile uint32_t systick_count_b = 0;

float32_t  snr;

void cmcc_enable(void)
{
	CMCC->CTRL.bit.CEN = CMCC_CTRL_CEN;
	while (CMCC->SR.reg != CMCC_SR_CSTS);
}

void cmcc_disable(void)
{
	CMCC->CTRL.bit.CEN = 0;
	while (CMCC->SR.bit.CSTS != 0);
}

/*
* \brief Main Function
*/
int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	cmcc_disable();
	CMCC->CFG.bit.CSIZESW = 1;
	cmcc_enable();
	
	printf("\r\n\r\n TCM configuration with linker \r\n");
		

	uint32_t i;
	arm_fir_instance_f32 S;
	arm_status status;
	float32_t  *inputF32, *outputF32;

	/* Initialize input and output buffer pointers */
	inputF32 = &testInput_f32_1kHz_15kHz[0];
	outputF32 = &testOutput[0];

	/* Call FIR init function to initialize the instance structure. */
	arm_fir_init_f32(&S, NUM_TAPS, (float32_t *)&firCoeffs32[0], &firStateF32[0], blockSize);

	/* ----------------------------------------------------------------------
	** Call the FIR process function for every blockSize samples
	** ------------------------------------------------------------------- */

	// Reload SysTick
	SysTick->LOAD = 0xFFFFFF;
	SysTick->VAL  = 0xFFFFFF;
	systick_count_a = _system_time_get(NULL);
	for(i=0; i < numBlocks; i++)
	{
		arm_fir_f32(&S, inputF32 + (i * blockSize), outputF32 + (i * blockSize), blockSize);
	}
	systick_count_b = _system_time_get(NULL);
	/* ----------------------------------------------------------------------
	** Compare the generated output against the reference output computed
	** in MATLAB.
	** ------------------------------------------------------------------- */

	snr = arm_snr_f32(&refOutput[0], &testOutput[0], TEST_LENGTH_SAMPLES);

	if (snr < SNR_THRESHOLD_F32)
	{
		status = ARM_MATH_TEST_FAILURE;
	}
	else
	{
		status = ARM_MATH_SUCCESS;
	}

	/* ----------------------------------------------------------------------
	** Loop here if the signal does not match the reference output.
	** ------------------------------------------------------------------- */

	if( status != ARM_MATH_SUCCESS)
	{
		while(1);
	}
	uint32_t cycle_count = systick_count_a - systick_count_b;
	
	printf("\r\n Number of SysTick counts for 'arm_fir_f32' %d\r\n", cycle_count);
	printf("\r\n Time taken is %5.4f Microseconds\r\n", (cycle_count / (float)120.0));
	
	while (1)
	{
	}
}