#include <atmel_start.h>
#include <hpl_dma.h>

static void dma_complete_callback(struct _dma_resource *resource)
{
	/*Enable DMA channel*/
	_dma_enable_transaction(0, false);
}

static void configure_dma(void)
{
	struct _dma_resource* dma_res;
	
	/*Set DMA source address*/
	_dma_set_source_address(0, (uint8_t*)&(((Adc *)(ADC_0.device.hw))->RESULT.reg));
	
	/*Set DMA destination address*/
	_dma_set_destination_address(0, (uint8_t*)&(((Sercom *)(USART_0.device.hw))->USART.DATA.reg));
	
	/*Set how many bytes to read*/
	_dma_set_data_amount(0, (uint32_t)1);
	
	/*Registering application callback after DMA transfer*/
	_dma_get_channel_resource(&dma_res, 0);
	
	dma_res->dma_cb.transfer_done = dma_complete_callback;
	
	_dma_set_irq_state(0, DMA_TRANSFER_COMPLETE_CB, true);
	
	/*Enable DMA channel*/
	_dma_enable_transaction(0, false);

}
int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	/*Enable ADC */
	adc_async_enable_channel(&ADC_0, 0);
	
	/*Configure and enable DMA*/
	configure_dma();
	
	/*USART enable*/
	usart_sync_enable(&USART_0);
	
	/* Start The timer */
	timer_start(&TIMER_0);
	
	while(1)
	{	
		/* Enter IDLE Sleep Mode */
		sleep(PM_SLEEPCFG_SLEEPMODE_STANDBY);
		
	}
}




















