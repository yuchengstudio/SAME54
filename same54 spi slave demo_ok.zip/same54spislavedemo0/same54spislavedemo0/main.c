#include <atmel_start.h>

#define SPI_TEST_SIZE 10

volatile uint32_t spi_tx_complete = 0;
volatile uint32_t spi_rx_complete = 0;

/**
 * Example of using Ethernet_SPI to write "Hello World" using the IO abstraction.
 */
static uint8_t example_SPI_MSTTX[SPI_TEST_SIZE] = {0,1,2,3,4,5,6,7,8,9};
static uint8_t example_SPI_MSTRX[SPI_TEST_SIZE] = {0};

static uint8_t example_SPI_SLVTX[SPI_TEST_SIZE] = {9,8,7,6,5,4,3,2,1,0};
static uint8_t example_SPI_SLVRX[SPI_TEST_SIZE] = {0};

/* SPI Slave Tx ����жϻص����� */
static void complete_cb_SPI_SLVTX(const struct spi_s_async_descriptor *const desc)
{
  /* Tx Transfer completed */
  spi_tx_complete = 1;
}

/* SPI Slave Tx ����жϻص����� */
static void complete_cb_SPI_SLVRX(const struct spi_s_async_descriptor *const desc)
{
  /* Rx Transfer completed */
  spi_rx_complete = 1;
}

void SPI_SLV_TX_RX_example(void)
{
  struct io_descriptor *io;
  spi_s_async_get_io_descriptor(&SPI_SLV, &io);

  spi_s_async_set_char_size(&SPI_SLV,SPI_CHAR_SIZE_8);

  /* ע��SPI Slave TX/RX���ʱ�Ļص����� - �����ָ���ֽ���SPI TX/RXʱ�����ע�����Ӧ�жϻص����� */
  spi_s_async_register_callback(&SPI_SLV, SPI_S_CB_TX, (FUNC_PTR)complete_cb_SPI_SLVTX);
  spi_s_async_register_callback(&SPI_SLV, SPI_S_CB_RX, (FUNC_PTR)complete_cb_SPI_SLVRX);
  spi_s_async_enable(&SPI_SLV);
}

void SPI_MST_TX_RX_example(void)
{
	struct io_descriptor *io;
	spi_m_sync_get_io_descriptor(&Ethernet_SPI, &io);

	spi_m_sync_enable(&Ethernet_SPI);
}

int main(void)
{
  uint32_t i = 0;
	struct spi_xfer xfer;
  struct io_descriptor *slv_spi_io;
  
  xfer.rxbuf = example_SPI_MSTRX;
	xfer.txbuf = example_SPI_MSTTX; 
  xfer.size  = SPI_TEST_SIZE; 
  
  spi_s_async_get_io_descriptor(&SPI_SLV, &slv_spi_io);
  
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

  /* Enabled Cache controller and Enable ICache/Disable DCache */
  hri_cmcc_write_CTRL_reg(CMCC,CMCC_CTRL_CEN);
  hri_cmcc_write_CFG_reg(CMCC, CMCC_CFG_DCDIS | CMCC_CFG_CSIZESW_CONF_CSIZE_4KB);
  
  SPI_SLV_TX_RX_example();
  SPI_MST_TX_RX_example();
  
	/* Replace with your application code */
	while (1) {
    printf("spi slave sending:\r\n");
    for (i = 0; i < SPI_TEST_SIZE; i++) {
      printf("0x%02X ",example_SPI_SLVTX[i]);
    }
    printf("\r\n");
    io_write(slv_spi_io, example_SPI_SLVTX, SPI_TEST_SIZE);  /* ���嵥��SPI Slave TX�ֽ����� */
    
    gpio_set_pin_level(SPI_KSZ8851SNL_CS, false);
    spi_m_sync_transfer(&Ethernet_SPI, &xfer);
    gpio_set_pin_level(SPI_KSZ8851SNL_CS, true);
    
    printf("spi master sending:\r\n");
    for (i = 0; i < SPI_TEST_SIZE; i++) {
      printf("0x%02X ",example_SPI_MSTTX[i]);
    }
    printf("\r\n");    
    
    while(spi_rx_complete == 0);
    
    io_read(slv_spi_io,  example_SPI_SLVRX, SPI_TEST_SIZE);  /* ���嵥��SPI Slave RX�ֽ����� */
    spi_s_async_flush_rx_buffer(&SPI_SLV);
    
    printf("spi slave receiving:\r\n");
    for (i = 0; i < SPI_TEST_SIZE; i++) {
      printf("0x%02X ",example_SPI_SLVRX[i]);
    }
    printf("\r\n");    
    
    printf("spi master receiving:\r\n");
    for (i = 0; i < SPI_TEST_SIZE; i++) {
      printf("0x%02X ",example_SPI_MSTRX[i]);
    }
    printf("\r\n");    
    
    spi_tx_complete = 0;
    spi_rx_complete = 0;
    memset(example_SPI_MSTRX,0,SPI_TEST_SIZE);
    memset(example_SPI_SLVRX,0,SPI_TEST_SIZE);
    delay_ms(1000);
	}
}
